﻿using System;

namespace ScaryCastle
{
    // ActorDirection
    public enum ActorDirection { Down, Up }

    // ActorSize
    public enum ActorSize { Small, Medium, Large }

    // AIStateName
    public enum AIStateName { Attack, Charge, Chase, CloseAttack, Decide, Idle, Move, Patrol, RangeAttack }

    // ApproachBehavior
    public enum ApproachBehavior
    {
        FaceToFace,     // Cara a cara (respetando la dirección del NPC)
        ClosestSide,    // Lado más cercano (sin cruzar al NPC)
        InFront         // Justo encima (para items o puertas)
    }

    // AttackType
    public enum AttackType { None, Melee, Ranged, Magic, Contact }

    // CardAction
    public enum CardAction
    {
        Damage,         // Aplica daño (Icono: Corazón Negro 🖤)
        Shield,         // Aplica escudo temporal (Icono: Corazón Azul 💙)
        Heal,           // Recupera vida (Icono: Corazón Rojo ❤️)
        ApplyEffect,    // Para la categoría Status (Icono: Calavera/Espiral 💀)
        Escape,         // Intenta huir (Icono: Salida >>)
        ModifyDice,     // Buff al dado (Icono: Dado Brillante ✨)
        DrawCards       // Robar cartas (Icono: Cartas 🃏)
    }

    // CardCategory
    public enum CardCategory { Attack, Defense, Healing, Prayer, Status }

    // ContentFolder
    public enum ContentFolder { Ambience, Atlases, Effects, Music, Fonts, FX, Video, Voices, System, Text }

    // ConsumptionType
    public enum ConsumptionType { Quantity, Durability, None }

    // DamageType
    public enum DamageType { Undefined, Physical, Acid, Explosive, Fire, Ice, Lightning, Poison }

    // Difficulty
    public enum Difficulty { Easy, Normal, Hard }

    // DustParticleKind
    public enum DustParticleKind { None, Dust, Ash }

    // EffectType
    public enum EffectType { None, Damage, Death, Heal, Luck, AddCondition, RemoveCondition }

    // EffectTarget
    public enum EffectTarget
    {
        Target, // Al que apunto (Enemigo o Jugador si es trampa)
        Self   // A mí mismo (Consumible o Buff)
    }

    // Faction
    public enum Faction { Neutral, Good, Evil }

    // GridMeasureType
    public enum GridMeasureType { BoundingBox, Collider, Hotspot }

    // HitEffect
    public enum HitEffect { None, Shake, Blink }

    // ImpactType
    public enum ImpactType { Low, Medium, High }

    // ImpactWordName
    public enum ImpactWordName { None, AghGreen, AghRed, BoomPurple, BoomRed, BangBlue, BangRed, CrackBlue, CrackYellow, CuackPurple, CuackYellow, Kapow, KapowStrong, OuchBlue, OuchGreen, PlopRed, PlopYellow, SlapBlue, SlapRed, Zap }

    // InventoryCategory
    public enum InventoryCategory { Common, Sacred }

    // ItemCategory
    public enum ItemCategory { Access, Explosive, Food, Luck, Medicine, Misc }

    // ItemProperty
    public enum ItemProperty { Chance, Durability, Health }

    // LargHandStyle
    public enum LargHandStyle { God, Devil }

    // LightKind
    public enum LightKind { Default, Lantern, Fire, Fireplace, Global, MuzzleFlash, Outdoor, Player }

    // LightState
    public enum LightState { Off, On, TurningOn, TurningOff }

    // LockType
    public enum LockType { None, GoldenKey }

    // LogVerb
    public enum LogVerb { Bought, Found, Requires, Used }

    // LootTag
    public enum LootTag { Heal, Weapoon }

    // MenuItemName
    public enum MenuItemName { Options, Resume, Start, Exit, ExitToMainMenu, Yes, No, Cancel, Accept, Credits, WishlistNow, Memoirs }

    // Message
    public enum Message { None }

    // MessageBoxOptions
    [Flags]
    public enum MessageBoxOptions
    {
        Yes = 1,
        No = 2,
        Cancel = 4,
        Accept = 8
    }

    // MessageKind
    public enum MessageKind { CannotPlaceItem, InventoryFull, NotEnoughCoins }

    // MouseCursorOutline
    public enum MouseCursorOutline { None, Green, Red }

    // MouseCursorState
    public enum MouseCursorState { Arrow, Cross, Down, Hand, Left, Right, Up, Wait }

    // PlaceholderTarget
    public enum PlaceholderTarget { Prop, Enemy, Any }

    // PlacementType
    public enum PlacementType
    {
        Floor,          // Suelo libre (lejos de paredes)
        WallFrontBase,  // Apoyado contra la pared de arriba (Vending Machine)
        WallFrontHang,  // Colgado en la pared de arriba (Cuadros, Antorchas)
        WallLeftBase,   // Apoyado contra la pared izquierda
        WallLeftHang,   // Colgado en la pared izquierda
        WallRightBase,  // Apoyado contra la pared derecha
        WallRightHang,  // Colgado en la pared derecha
        Ceiling,        // Techo (lámparas, telarañas)
        WalkArea        // Cualquier lugar del suelo navegable
    }

    // PlayerNumber
    public enum PlayerNumber { None = -1, One = 0, Two = 1, Three = 2, Four = 3 }

    // PropState
    public enum PropState { None, Closed, Empty, TurnedOff, Open, Locked, Unlocked }

    // Realm
    public enum Realm { Earthly, Infernal, Celestial }

    // RenderLayer
    public enum RenderLayer { BehindBackground, Background, OverBackground, Default, Foreground, ForegroundNoLight }

    // RideDoorDirection
    public enum RideDoorDirection { Up, Right, Down, Left }

    // RoomType
    public enum RoomType { Connector, Start, Exit }

    // SpeechBubbleState
    public enum SpeechBubbleState { Hidden, Typing, Idle }

    // TestPolygon
    public enum TestPolygon { Hotspot, Collider }

    // ThrowableBounceIntensity
    public enum ThrowableBounceIntensity { Low, Medium, High }

    // UIControlGroupLayoutStyle
    public enum UIControlGroupLayoutStyle { Vertically, Horizontally }

    // Verb
    public enum Verb { Enter, Exit, Use }

    // VolumeCategory
    public enum VolumeCategory { Ambient, FX, Music, Voice, Master }
}
