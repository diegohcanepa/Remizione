﻿namespace ScaryCastle
{
    /// <summary>
    /// ActorStateNames
    /// </summary>
    internal static class ActorStateNames
    {
        public const string Animate = nameof(Animate);
        public const string CloseAttack = nameof(CloseAttack);
        public const string ContactDamage = nameof(ContactDamage);
        public const string Consume = nameof(Consume);
        public const string CreateItem = nameof(CreateItem);
        public const string Death = nameof(Death);
        public const string Hurt = nameof(Hurt);
        public const string Idle = nameof(Idle);
        public const string Move = nameof(Move);
        public const string PickUp = nameof(PickUp);
        public const string Stand = nameof(Stand);
        public const string Talk = nameof(Talk);
        public const string ThrowItem = nameof(ThrowItem);
    }
}
