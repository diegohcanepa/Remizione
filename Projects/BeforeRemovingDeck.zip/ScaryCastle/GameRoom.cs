﻿using Adberration;
using Adberration.Scripting;
using Engendro;
using Engendro.Audio;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;

namespace ScaryCastle
{
    /// <summary>
    /// GameRoom
    /// </summary>
    public class GameRoom : Room
    {
        #region Private fields

        private Color brightnessColor;
        private int currentDrawIndex;
        private static DustEmitter dustEmitter = null!;
        private static FireflyEmitter fireflyEmitter = null!;
        private RenderTarget2D? lightMapTarget;
        private readonly List<Light> lights = [];
        private readonly List<ILightSource> lightSources = [];
        private static Light playerLight = null!;
        private string lastKnownMusicTag = string.Empty;
        private FacingDirection lastKnownPlayerDirection;
        private Vector2? lastKnownPlayerPosition;
        private readonly List<TriggerArea> triggerAreas = [];
        private readonly List<WalkArea> walkAreas = [];

        #endregion

        #region Constructor

        // Constructor
        public GameRoom(GameSession session, string name)
            : base(session, name)
        {
            this.Session = session;
            this.Lights = new NamedObjectReadOnlyCollection<Light>(lights);
            this.TriggerAreas = new RoomAreaReadOnlyCollection<TriggerArea>(triggerAreas);
            this.WalkAreas = new RoomAreaReadOnlyCollection<WalkArea>(walkAreas);

            dustEmitter ??= new DustEmitter(session, 6, 1000, 35);
            fireflyEmitter ??= new FireflyEmitter(session, 1, 500, 20);

            // Player light
            playerLight ??= new Light(Game, "PlayerLight")
            {
                LightKind = LightKind.Player,
                PivotOrigin = RectanglePoint.Center,
                Position = Screen.Center,
                Scale = new Vector2(3)
            };
            playerLight.TurnOff(true);
        }

        #endregion

        #region Private members

        // ApplyLightMap
        private void ApplyLightMap(RenderTarget2D target, RenderTarget2D? lightMap)
        {
            if (Game.SpriteBatch == null || lightMap == null)
                return;

            Game.SpriteBatch.Begin(transformMatrix: Game.Camera.GetTransformationMatrix(), samplerState: SamplerState.LinearClamp, blendState: BlendState.AlphaBlend, effect: ScaryCastleGame.Effects.Lighting.Effect);
            ScaryCastleGame.Effects.Lighting.LightMask.SetValue(lightMap);
            ScaryCastleGame.Effects.Lighting.Effect.CurrentTechnique.Passes[0].Apply();
            Game.SpriteBatch.Draw(target, Screen.Area, Color.White);
            Game.SpriteBatch.End();
        }

#if DEBUG

        // DrawDebugBoxes
        private void DrawDebugBoxes()
        {
            Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, null);
            for (int i = 0; i < CulledThings.Count; i++)
            {
                if (CulledThings[i] is GameThing thing)
                    thing.DrawDebugBoxes();
            }
            Game.SpriteBatch.End();
        }

#endif

        // DrawDustParticles
        private void DrawDustParticles(GameTime gameTime)
        {
            if (dustEmitter != null)
            {
                Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, null);
                dustEmitter.Draw(gameTime);
                Game.SpriteBatch.End();
            }
        }

        // DrawEnvironmentParticles
        private void DrawEnvironmentParticles(GameTime gameTime)
        {
            if (DustParticleKind != DustParticleKind.None)
                DrawDustParticles(gameTime);

            if (AllowFireflyParticles)
                DrawFireflyParticles(gameTime);
        }

        // DrawFireflyParticles
        private void DrawFireflyParticles(GameTime gameTime)
        {
            if (fireflyEmitter != null)
            {
                Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, null);
                fireflyEmitter.Draw(gameTime);
                Game.SpriteBatch.End();
            }
        }

        // DrawFloatingHearts
        private void DrawFloatingHearts(GameTime gameTime)
        {
            Game.SpriteBatch.Begin(Session.Camera);
            for (var i = Session.ObjectPools.FloatingHearts.InUse.Count - 1; i >= 0; i--)
            {
                Session.ObjectPools.FloatingHearts.InUse[i].Draw(gameTime);
            }
            Game.SpriteBatch.End();
        }

        // DrawFloatingTexts
        private void DrawFloatingTexts(GameTime gameTime)
        {
            Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp);
            for (var i = Session.ObjectPools.FloatingTexts.InUse.Count - 1; i >= 0; i--)
            {
                Session.ObjectPools.FloatingTexts.InUse[i].Draw(gameTime);
            }
            Game.SpriteBatch.End();
        }

        // DrawImpactWords
        private void DrawImpactWords(GameTime gameTime)
        {
            if (Session.ImpactWordPool.InUse.Count == 0)
                return;

            Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, null);
            for (int i = 0; i < Session.ImpactWordPool.InUse.Count; i++)
            {
                Session.ImpactWordPool.InUse[i].Draw(gameTime);
            }
            Game.SpriteBatch.End();
        }

        // DrawShadows
        private void DrawShadows(GameTime gameTime)
        {
            Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, null);
            for (int i = 0; i < CulledThings.Count; i++)
            {
                if (CulledThings[i] is GameThing thing)
                    thing.DrawShadow(gameTime);
            }
            Game.SpriteBatch.End();
        }

        // DrawThings
        private void DrawThings(GameTime gameTime, RenderLayer renderLayer)
        {
            var depth = (int)renderLayer;

            for (var i = currentDrawIndex; i < CulledThings.Count; i++)
            {
                if (CulledThings[i].RenderLayerDepth != depth)
                {
                    break;
                }
                else if (CulledThings[i] is GameThing thing)
                {
                    ShaderEffect? effect = null;

                    if (thing.IsBlinking && thing != Session.Player)
                    {
                        ScaryCastleGame.Effects.ColorReduction.SetColor(1, 0, 0, 1);
                        effect = ScaryCastleGame.Effects.ColorReduction;
                    }
                    else if (!Session.IsAwaiting && Session.InteractionContext.Target == thing && thing.HighlightInteraction && thing.Opacity == 1)
                    {
                        ScaryCastleGame.Effects.ColorSaturation.SetColor(.8f, .8f, .8f, 0);
                        effect = ScaryCastleGame.Effects.ColorSaturation;
                    }

                    Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, effect?.Effect);
                    thing.Draw(gameTime);
                    Game.SpriteBatch.End();
                    currentDrawIndex++;
                }
            }
        }

        // PrepareLightMap
        private void PrepareLightMap(GameTime gameTime, RenderTarget2D? renderTarget)
        {
            if (renderTarget == null)
                return;

            // Save current render target
            var previousRenderTarget = Game.RenderTargets.CurrentTarget;

            Game.GraphicsDevice.SetRenderTarget(renderTarget);

            Game.GraphicsDevice.Clear(LightMapColor);

            if (AllowGlobalLight)
            {
                Game.SpriteBatch.Begin(Game.Camera, SamplerState.LinearClamp, BlendState.Additive, null);
                Session.Environment.GlobalLight.Draw(gameTime);
                Game.SpriteBatch.End();
            }

            Game.SpriteBatch.Begin(Session.Camera, SamplerState.LinearClamp, BlendState.Additive, null);

            // Owned lights
            for (int i = 0; i < lights.Count; i++)
            {
                if (lights[i].IsEmitting)
                {
                    if (lights[i].BoundingBox.Intersects(Session.Camera.CullingBox))
                    {
                        lights[i].Draw(gameTime);
                    }
                }
            }

            // Light sources
            for (int i = 0; i < CulledThings.Count; i++)
            {
                if (CulledThings[i] is GameThing thing && thing.IsEmittingLight && CulledThings[i].IsInCullingBox)
                    thing.DrawLights(gameTime);
            }

            if (Session.Player != null)
            {
                playerLight.Position = Session.Player.GetAbsolutePoint(15, 15);
                playerLight.Draw(gameTime);
            }

            if (BrightnessModifier > 0)
                Game.Shapes.DrawRectangle(Session.Viewport.ToRectangle(), brightnessColor);

            Game.SpriteBatch.End();

            if (AllowFireflyParticles)
                DrawFireflyParticles(gameTime);

            // Restore previous render target
            Game.GraphicsDevice.SetRenderTarget(previousRenderTarget);
        }

        // TestTriggerAreas
        private void TestTriggerAreas()
        {
            if (triggerAreas.Count > 0 && !Session.IsAwaiting && Session.Player != null)
            {
                for (int i = 0; i < TriggerAreas.Count; i++)
                {
                    TriggerAreas[i].Trigger(Session.Player);
                    if (TriggerAreas[i].Await && Session.IsAwaiting)
                        break;
                }
            }
        }

        #endregion

        #region Protected members

        // ClearWalkAreas
        protected void ClearWalkAreas()
        {
            walkAreas.Clear();
            WalkArea = null;
        }

        // GetAtlasPath
        protected override string GetAtlasPath()
        {
            return ContentManagerExtension.EncodePath(ContentFolder.Atlases, AtlasName);
        }

        // OnDraw
        protected override void OnDraw(GameTime gameTime)
        {
            // Prepare light map
            if (CanUseLightingSystem)
            {
                if (lightMapTarget != null && lightMapTarget.IsDisposed)
                    lightMapTarget = Game.RenderTargets.AuxiliaryTargets[0];

                PrepareLightMap(gameTime, lightMapTarget);
            }

            currentDrawIndex = 0;

            // BehindBackground (layer)
            DrawThings(gameTime, RenderLayer.BehindBackground);

            // Background
            Game.SpriteBatch.Begin(Session.Camera, SamplerState.PointClamp, BlendState.AlphaBlend, null);
            base.OnDraw(gameTime);
            Game.SpriteBatch.End();

            // Background (layer)
            DrawThings(gameTime, RenderLayer.Background);

            // OverBackground (layer)
            DrawThings(gameTime, RenderLayer.OverBackground);

            // Shadows
            DrawShadows(gameTime);

            // Default (layer)
            DrawThings(gameTime, RenderLayer.Default);

            // Environment particles
            DrawEnvironmentParticles(gameTime);

            // Foreround (layer)
            DrawThings(gameTime, RenderLayer.Foreground);

            Session.Environment.Lightning.Draw(gameTime);

            // Apply light map
            if (CanUseLightingSystem && Game.RenderTargets != null)
            {
                Game.RenderTargets.Swap();
                ApplyLightMap(Game.RenderTargets.PreviousTarget, lightMapTarget);
            }

            // Foreround (layer)
            DrawThings(gameTime, RenderLayer.ForegroundNoLight);

            // Draw hearts
            DrawFloatingHearts(gameTime);

            // Draw texts (hit numbers, etc)
            DrawFloatingTexts(gameTime);

            // Impact words
            DrawImpactWords(gameTime);

#if DEBUG
            DrawDebugBoxes();
#endif
        }

        // OnHandleInput
        protected override HandleInputResult OnHandleInput(GameTime gameTime)
        {
            if (Session.Player != null)
                return Session.Player.HandleInput(gameTime);
            else
                return base.OnHandleInput(gameTime);
        }

        // OnLoad
        protected override void OnLoad()
        {
            base.OnLoad();

            Session.Environment.GlobalLight.Scale = GlobalLightSize;

            if (DustParticleKind != DustParticleKind.None)
                dustEmitter?.Activate();

            if (AllowFireflyParticles)
                fireflyEmitter?.Activate();

            lightMapTarget = Game.RenderTargets.AuxiliaryTargets[0];
            lightSources.Clear();

            // Prepare lights
            if (Atlas != null)
            {
                for (int i = 0; i < Lights.Count; i++)
                {
                    Lights[i].Prepare(Atlas);
                }
            }
        }

        // OnUnload
        protected override void OnUnload()
        {
            base.OnUnload();
            Session.ImpactWordPool.ReturnAll();
            dustEmitter?.Deactivate();
            fireflyEmitter?.Deactivate();
        }

        // OnUpdate
        protected override void OnUpdate(GameTime gameTime)
        {
            base.OnUpdate(gameTime);

            for (int i = 0; i < Session.ImpactWordPool.InUse.Count; i++)
            {
                Session.ImpactWordPool.InUse[i].Update(gameTime);
            }

            TestTriggerAreas();

            // Lights
            for (int i = 0; i < lights.Count; i++)
            {
                lights[i].Update(gameTime);
            }

            if (AllowGlobalLight)
                Session.Environment.GlobalLight.Update(gameTime);

            playerLight.Update(gameTime);

            // Dust particles
            if (DustParticleKind != DustParticleKind.None)
                dustEmitter?.Update(gameTime);

            // Firefly particles
            if (AllowFireflyParticles)
                fireflyEmitter?.Update(gameTime);

            // Floating hearts
            for (var i = 0; i < Session.ObjectPools.FloatingHearts.InUse.Count; i++)
            {
                Session.ObjectPools.FloatingHearts.InUse[i].Update(gameTime);
            }

            // Floating texts
            for (var i = 0; i < Session.ObjectPools.FloatingTexts.InUse.Count; i++)
            {
                Session.ObjectPools.FloatingTexts.InUse[i].Update(gameTime);
            }
        }

        #endregion

        // AddLight
        public Light AddLight(string name)
        {
            CodeContract.NotDuplicate(Lights, name, nameof(name));
            var result = new Light(Game, name);
            lights.Add(result);
            return result;
        }

        // AddTriggerArea
        public TriggerArea AddTriggerArea(string name, Script routine, Script? exitRoutine, bool await, bool stopActor, bool once, FlagCondition? condition, params Vector2[] vertices)
        {
            CodeContract.NotDuplicate(TriggerAreas, name, nameof(name));
            var result = new TriggerArea(this, name, routine, exitRoutine, await, stopActor, once, condition, vertices);
            triggerAreas.Add(result);

            return result;
        }

        // AddWalkArea
        public WalkArea AddWalkArea(string name, string vertices)
        {
            return AddWalkArea(name, ReadOnlyPolygon.GetVertices(vertices));
        }

        // AddWalkArea
        public WalkArea AddWalkArea(string name, params Vector2[] vertices)
        {
            CodeContract.NotDuplicate(WalkAreas, name, nameof(name));

            WalkArea result = new(this, name, null, vertices);
            walkAreas.Add(result);

            if (walkAreas.Count == 1)
                WalkArea = WalkAreas[0];

            return result;
        }

        // AllowFireflyParticles
        [ScriptProperty]
        public bool AllowFireflyParticles { get; set; }

        // AllowGlobalLight
        [ScriptProperty]
        public bool AllowGlobalLight { get; set; }

        // AllowPauseMenu
        [ScriptProperty]
        public bool AllowPauseMenu { get; set; } = true;

        // BrightnessModifier
        [ScriptProperty]
        public float BrightnessModifier
        {
            get;
            set
            {
                if (value != field)
                {
                    field = Math.Clamp(value, 0, 1);
                    brightnessColor = Color.White * field;
                }
            }
        }

        // CanUseLightingSystem
        public bool CanUseLightingSystem => Session.LightingSystem && LightingSystem;

        // DustParticleKind
        [ScriptProperty]
        public DustParticleKind DustParticleKind { get; set; } = DustParticleKind.Ash;

        // GlobalLightSize
        [ScriptProperty]
        public Vector2 GlobalLightSize
        {
            get => Session.Environment.GlobalLight.Scale;
            set => Session.Environment.GlobalLight.Scale = value;
        }

        // IsProcedural
        [ScriptProperty]
        public virtual bool IsProcedural => false;

        // IsWalkable
        public virtual bool IsWalkable => true;

        // LightingSystem
        [ScriptProperty]
        public bool LightingSystem { get; set; }

        // LightMapColor
        [ScriptProperty]
        public Color LightMapColor { get; set; } = new Color(10, 10, 25);

        // Lights
        public NamedObjectReadOnlyCollection<Light> Lights { get; }

        // PreserveBeforeGateway
        [ScriptMethod]
        public void PreserveBeforeGateway()
        {
            if (Session.Player != null)
            {
                lastKnownPlayerDirection = Session.Player.Direction;
                lastKnownPlayerPosition = Session.Player.Position;
            }

            lastKnownMusicTag = AudioManager.Music.CurrentTag;
        }

        // RestoreAfterGateway
        [ScriptMethod]
        public void RestoreAfterGateway()
        {
            if (lastKnownPlayerPosition.HasValue && Session.Player != null)
            {
                Session.Player.Position = lastKnownPlayerPosition.Value;
                Session.Player.Direction = lastKnownPlayerDirection;
                Children.Add(Session.Player);
                Session.Player.FlipHorizontally();
                Session.Camera.FollowTarget(Session.Player, true);
            }

            if (!string.IsNullOrWhiteSpace(lastKnownMusicTag))
                AudioManager.Music.PlayTag(lastKnownMusicTag);
        }

        // SelectWalkArea
        public void SelectWalkArea(string name)
        {
            WalkArea = WalkAreas.Find(name) ?? throw new InvalidOperationException($"Walk area '{name}' not found.");
        }

        // Session
        public new GameSession Session { get; }

        // ShowLightning
        public void ShowLightning()
        {
            var interval = new Int32Range(30);
            int count = 8;
            Session.Environment.GlobalLight.Flash(interval, count);
        }

        // TriggerAreas
        public RoomAreaReadOnlyCollection<TriggerArea> TriggerAreas { get; }

        // WalkArea
        public WalkArea? WalkArea { get; private set; }

        // WalkAreas
        public RoomAreaReadOnlyCollection<WalkArea> WalkAreas { get; }
    }
}
