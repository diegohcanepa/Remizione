﻿using Engendro;
using Engendro.Input;
using Microsoft.Xna.Framework;

namespace ScaryCastle
{
    /// <summary>
    /// CombatManager
    /// </summary>
    public sealed class CombatManager : GameObject, IInputHandler
    {
        private CombatManagerState currentState;
        private readonly UITargetMeter targetMeter;

        // Constructor
        public CombatManager(Actor player, Actor enemy)
            : base(player.Game)
        {
            this.Session = player.Session;
            this.Player = player;
            this.Enemy = enemy;
            this.targetMeter = new UITargetMeter(enemy);
            this.currentState = new PlayerTurnState(this);
        }

        #region Protected members

        // OnDraw
        protected override void OnDraw(GameTime gameTime)
        {
            targetMeter.Draw(gameTime);
        }

        // OnUpdate
        protected override void OnUpdate(GameTime gameTime)
        {
            currentState?.Update(gameTime);
            targetMeter.Update(gameTime);
        }

        #endregion

        // CanSuspend
        public bool CanSuspend { get; set; } = true;

        // Enemy
        public Actor Enemy { get; }

        // HandleInput
        public HandleInputResult HandleInput(GameTime gameTime)
        {
            if (currentState == null)
                return HandleInputResult.Unhandled;
            else
                return currentState.HandleInput(gameTime);
        }

        // Player
        public Actor Player { get; }

        // Session
        public GameSession Session { get; }

        // TransitionTo
        public void TransitionTo(CombatManagerState newState)
        {
            currentState?.Exit();
            currentState = newState;
            currentState.Enter();
        }
    }
}