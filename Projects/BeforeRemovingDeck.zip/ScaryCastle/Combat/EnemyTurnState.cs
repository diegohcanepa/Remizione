﻿using Adberration.Scripting;
using Engendro;
using Engendro.Input;
using Microsoft.Xna.Framework;

namespace ScaryCastle
{
    /// <summary>
    /// EnemyTurnState
    /// </summary>
    public sealed class EnemyTurnState : CombatManagerState
    {
        // Constructor
        public EnemyTurnState(CombatManager manager)
            : base(manager)
        {
        }

        // Enter
        public override void Enter()
        {
            base.Enter();
            if (Manager.Enemy.Definition != null)
                EffectDescriptor.Apply(Manager.Enemy.Definition.Effects, Manager.Enemy, Manager.Player, AttackType.Contact);
        }

        // Update
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (TimeInState > 3)
                Manager.TransitionTo(new PlayerTurnState(Manager));
        }
    }
}
