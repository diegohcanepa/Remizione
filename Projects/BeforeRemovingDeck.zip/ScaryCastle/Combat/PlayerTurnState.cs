﻿using Adberration.Scripting;
using Engendro;
using Engendro.Input;
using Microsoft.Xna.Framework;

namespace ScaryCastle
{
    /// <summary>
    /// PlayerTurnState
    /// </summary>
    public sealed class PlayerTurnState : CombatManagerState
    {
        // PlayerTurnState
        public PlayerTurnState(CombatManager manager)
            : base(manager)
        {
        }

        // OnHandleInput
        protected override HandleInputResult OnHandleInput(GameTime gameTime)
        {
            var context = Manager.Session.InteractionContext;

            if (context.Target != null)
            {
                if (InputManager.DefaultPlayer.Mouse.IsLeftButtonPressed())
                {
                    if (context.HeldItem is Item item)
                    {
                        if (context.UseWithScript != null)
                        {
                            context.HeldItem = null;
                            Manager.Session.AwaitScript(context.UseWithScript);
                        }
                        else if (Manager.Session.ScriptLibrary.FindRoutine($"Use{item.Name}") is Script script)
                        {
                            context.HeldItem = null;
                            Manager.Session.AwaitScript(script);
                        }
                    }
                }
            }

            return HandleInputResult.Handled;
        }
    }
}
