﻿using Engendro;
using Engendro.Audio;
using Engendro.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ScaryCastle.Effects;
using System;

namespace ScaryCastle
{
    /// <summary>
    /// MouseCursor
    /// </summary>
    public static class MouseCursor
    {
        #region Private fields

        private static readonly AtlasImage?[] cursorImages;
        private static readonly ImageSprite cursorSprite;
        private static readonly Vector4 outlineColorGreen = ColorPalette.MouseCursorGreenOutline;
        private static readonly Vector4 outlineColorRed = ColorPalette.MouseCursorRedOutline;
        private static readonly Vector2Tween scaleTween = new();
        private static readonly FloatTween shakeTween = new();
        private static readonly TextSprite textSprite;

        #endregion

        #region Constructor

        // Constructor
        static MouseCursor()
        {
            // Cursor sprite
            cursorSprite = new ImageSprite(EngendroGame.Instance)
            {
                PivotOrigin = RectanglePoint.Center,
                Scale = GetCurrentScale()
            };

            const string prefix = "MouseCursor";
            var names = Enum.GetNames<MouseCursorState>();

            cursorImages = new AtlasImage[names.Length];
            for (var i = 0; i < cursorImages.Length; i++)
            {
                var imageName = $"{prefix}{names[i]}";
                cursorImages[i] = Atlases.UI.FindImage(imageName);
            }

            textSprite = new(EngendroGame.Instance, Fonts.CommonOutline)
            {
                Color = ColorPalette.Text.Sentence,
                PivotOrigin = RectanglePoint.LeftTop,
                Scale = ScaleInfo.UISentence
            };
        }

        #endregion

        #region Private members

        // ClampTextToScreen
        private static void ClampTextToScreen()
        {
            var offset = CustomImage == null ? 4 : 2;

            if (!textSprite.IsEmpty)
            {
                textSprite.PivotOrigin = RectanglePoint.LeftTop;
                textSprite.Position = cursorSprite.BoundingBox.GetPoint(RectanglePoint.RightBottom, -offset, -offset);

                if (!textSprite.BoundingBox.IsInside(EngendroGame.Instance.Camera.VisibleBox))
                {
                    textSprite.PivotOrigin = RectanglePoint.RightTop;
                    textSprite.Position = cursorSprite.BoundingBox.GetPoint(RectanglePoint.LeftBottom, offset, -offset);
                }

                if (textSprite.BoundingBox.Bottom >= Screen.NativeHeight)
                    textSprite.Y -= 10;
            }
        }

        // GetCurrentScale
        private static Vector2 GetCurrentScale()
        {
            return CustomImage != null ? ScaleInfo.InventoryHeldItem : ScaleInfo.UIElement.Large;
        }

        // InvalidateCursorImage
        private static void InvalidateCursorImage()
        {
            if (CustomImage != null)
                cursorSprite.Image = CustomImage;
            else
                cursorSprite.Image = cursorImages[(int)State];

            cursorSprite.Scale = GetCurrentScale();
            cursorSprite.PivotOrigin = State == MouseCursorState.Arrow ? RectanglePoint.LeftTop : RectanglePoint.Center;
        }

        #endregion

        // AnimateClick
        public static void AnimateClick()
        {
            scaleTween.Start(TweenStyle.QuadraticIn, GetCurrentScale() * .9f, GetCurrentScale(), 150);
            cursorSprite.Tweens.ScaleTween = scaleTween;
        }

        // CustomImage
        public static AtlasImage? CustomImage
        {
            get;
            set
            {
                if (value != field)
                {
                    field = value;
                    InvalidateCursorImage();
                }
            }
        }

        // Draw
        public static void Draw(GameTime gameTime)
        {
            OutlineEffect? effect = CustomImage != null && OutlineColor != MouseCursorOutline.None ? ScaryCastleGame.Effects.Outline : null;

            if (effect != null && cursorSprite.Image?.Atlas != null)
            {
                effect.Color.SetValue(OutlineColor == MouseCursorOutline.Green ? outlineColorGreen : outlineColorRed);
                effect.TextureSize.SetValue(new Vector2(cursorSprite.Image.Atlas.Texture.Width, cursorSprite.Image.Atlas.Texture.Height));
                effect.Thickness.SetValue(1);
            }

            EngendroGame.Instance.SpriteBatch.Begin(EngendroGame.Instance.Camera, SamplerState.PointClamp, effect?.Effect);
            cursorSprite.X += shakeTween.IsRunning ? shakeTween.CurrentValue : 0;
            cursorSprite.Draw(gameTime);
            cursorSprite.X -= shakeTween.IsRunning ? shakeTween.CurrentValue : 0;
            EngendroGame.Instance.SpriteBatch.End();

            EngendroGame.Instance.SpriteBatch.Begin(EngendroGame.Instance.Camera);
            if (State is MouseCursorState.Cross || CustomImage != null)
                textSprite.Draw(gameTime);
            EngendroGame.Instance.SpriteBatch.End();
        }

        // OutlineColor
        public static MouseCursorOutline OutlineColor { get; set; }

        // PerformClick
        public static void PerformClick()
        {
            AnimateClick();
            Sound.Play(SoundNames.Interact);
        }

        // Reset
        public static void Reset()
        {
            CustomImage = null;
            State = MouseCursorState.Arrow;
            OutlineColor = MouseCursorOutline.None;
            Text = null;
        }

        // Shake
        public static void Shake()
        {
            shakeTween.Start(TweenStyle.CubicInOut, 0, 1, 50, 4);
        }

        // State
        public static MouseCursorState State
        {
            get;
            set
            {
                if (value != field)
                {
                    field = value;
                    InvalidateCursorImage();
                }
            }
        }

        // Text
        public static string? Text
        {
            get => textSprite.Text;
            set => textSprite.Text = value;
        }

        // Update
        public static void Update(GameTime gameTime)
        {
            cursorSprite.Position = InputManager.DefaultPlayer.Mouse.VirtualPosition;
            cursorSprite.Update(gameTime);
            shakeTween.Update(gameTime);
            ClampTextToScreen();
        }
    }
}