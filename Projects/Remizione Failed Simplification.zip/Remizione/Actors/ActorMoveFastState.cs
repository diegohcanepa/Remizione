﻿using Microsoft.Xna.Framework;

namespace Remizione
{
    /// <summary>
    /// ActorMoveFastState
    /// </summary>
    public sealed class ActorMoveFastState : ActorAnimatedState
    {
        private int willpowerPenaltyCooldown;

        // Constructor
        public ActorMoveFastState(Actor owner)
            : base(owner, ActorStateNames.MoveFast, true)
        {
        }

        // Enter
        public override void Enter()
        {
            base.Enter();
            willpowerPenaltyCooldown = Owner.Stats.WillpowerDegradationInterval;
        }

        // Update
        public override void Update(GameTime gameTime)
        {
            if (!Owner.Session.CombatManager.IsActive)
                return;

            if (willpowerPenaltyCooldown > 0)
            {
                willpowerPenaltyCooldown -= gameTime.ElapsedGameTime.Milliseconds;
            }
            else
            {
                Owner.Willpower -= 1;
                willpowerPenaltyCooldown = Owner.Stats.WillpowerDegradationInterval;
            }
        }
    }
}
