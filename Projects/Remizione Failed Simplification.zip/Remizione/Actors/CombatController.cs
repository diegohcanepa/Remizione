﻿namespace Remizione
{
    /// <summary>
    /// CombatController
    /// </summary>
    public sealed class CombatController
    {
        private readonly Actor.ActorStateMachine stateMachine;

        // Constructor
        public CombatController(Actor.ActorStateMachine stateMachine)
        {
            this.stateMachine = stateMachine;
        }

        // ExecuteAction
        public void ExecuteAction()
        {
            if (stateMachine.Owner.AttackSkill is Item skill)
            {
                if (skill.Range == 0)
                {
                    stateMachine.ChangeState(ActorStateNames.Charge);
                }
                else
                {
                    // Range attack
                }
            }
        }
    }
}