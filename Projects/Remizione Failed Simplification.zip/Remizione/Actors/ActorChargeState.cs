﻿using EngendroAdventure;
using Microsoft.Xna.Framework;

namespace Remizione
{
    /// <summary>
    /// ActorChargeState
    /// </summary>
    public sealed class ActorChargeState : ActorState
    {
        // Constructor
        public ActorChargeState(Actor owner)
            : base(owner, ActorStateNames.Charge)
        {
        }

        // CheckTransitions
        public override string? CheckTransitions()
        {
            if (!Owner.IsMoving)
                return ActorStateNames.CloseAttack;
            else
                return ActorStateNames.Stand;
        }

        // MoveTowardsTarget
        private void MoveTowardsTarget()
        {
            if (Owner.Target is GameThing target)
            {
                Owner.FastMove = true;

                var front = target.Direction == FacingDirection.Right && Owner.X > target.X ||
                            target.Direction == FacingDirection.Left && Owner.X < target.X;

                Owner.MoveTo(target.GetApproachPosition(target, front));
            }
        }

        // Enter
        public override void Enter() => MoveTowardsTarget();
    }
}
