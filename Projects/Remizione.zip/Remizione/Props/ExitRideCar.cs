﻿using Adberration.Scripting;
using Engendro;
using Microsoft.Xna.Framework;

namespace Remizione
{
    /// <summary>
    /// ExitRideCar
    /// </summary>
    public sealed class ExitRideCar : IsometricProp
    {
        private readonly Light frontLight;
        private static readonly Vector2 frontLightPosition = new(25, 13);
        private readonly Light rearLight;
        private static readonly Vector2 rearLightPosition = new(11, 20);

        // Constructor
        public ExitRideCar(GameSession session, string name)
            : base(session, name)
        {
            HitEffect = HitEffect.Shake;

            this.frontLight = new Light(session.Game, "<rear>")
            {
                Color = Color.Green,
                Scale = new(2, 1)
            };

            this.rearLight = new Light(session.Game, "<front>")
            {
                Color = Color.Red,
                Scale = new(2, 1)
            };
        }

        #region Protected members

        // OnDrawLights
        protected override void OnDrawLights(GameTime gameTime)
        {
            base.OnDrawLights(gameTime);

            frontLight.Position = this.GetAbsolutePoint(frontLightPosition);
            frontLight.Draw(gameTime);

            rearLight.Position = this.GetAbsolutePoint(rearLightPosition);
            rearLight.Draw(gameTime);
        }

        // OnLoad
        protected override void OnLoad()
        {
            base.OnLoad();
            IsTurnedOn = false;
            AttachedLight?.TurnOff(true);
            this.AnimationPlayer.Play("Off");
        }

        // OnUpdate 
        protected override void OnUpdate(GameTime gameTime)
        {
            base.OnUpdate(gameTime);

            if (IsEmittingLight)
            {
                frontLight.Update(gameTime);
                rearLight.Update(gameTime);
            }
        }

        #endregion

        // IsEmittingLight
        public override bool IsEmittingLight => IsTurnedOn;

        // IsTurnedOn
        [ScriptProperty]
        public bool IsTurnedOn { get; private set; }

        // TurnOn
        [ScriptMethod]
        public void TurnOn()
        {
            AnimationPlayer.Play("On", false);
            AttachedLight?.TurnOn();
            IsTurnedOn = true;
        }
    }
}
