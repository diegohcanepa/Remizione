﻿using Adberration;
using Adberration.Scripting;
using Engendro;
using Engendro.Audio;
using Engendro.Input;
using Engendro.PathFinding;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;

namespace Remizione
{
    /// <summary>
    /// GameThing 
    /// </summary>
    public abstract class GameThing : Thing, IHoleArea, ILightSource
    {
        #region Private fields

        private PlacementMode colliderPlacement = PlacementMode.Relative;
        private string displayNameKey = string.Empty;
        private readonly Polygon holePolyInflated = new();
        private readonly Polygon holePoly = new();
        private readonly Polygon hotspotPoly = new();
        private PlacementMode hotspotPlacement = PlacementMode.Relative;
        private int health;
        private Vector2Tween? hurtShakeTween;
        private FloatTween? hurtTween;
        private float floatingForce;
        private FloatTween? floatingTween;
        private ImpactWord? impactWord;
        private bool isCollisionDirty;
        private bool isHotspotDirty = true;
        private readonly Vector2Tween knockbackTween = new();
        private int maxHealth;
        private PathNode[]? pathNodes;
        private RenderLayer renderLayer;
        private int renderLayerDepth;
        private bool shouldClampToWalkablePosition;
        private WalkArea? walkArea;
        private string walkAreaName = string.Empty;

        #endregion

        #region Constructor

        // Constructor
        protected GameThing(GameSession session, string name)
            : base(session, name)
        {
            this.RenderLayer = RenderLayer.Default;
            this.Session = session;
            this.LootTableName = StaticName;
        }

        #endregion

        #region IHoleArea explicit implementation

        // ClampOutside
        Vector2 IHoleArea.ClampOutside(Vector2 position)
        {
            if (!Collider.IsEmpty)
            {
                InvalidateCollisionPolygons();
                if (holePoly.Contains(position))
                    position = holePolyInflated.GetClosestPointOnEdge(position);
            }

            return position;
        }

        // CollectPathNodes
        void IHoleArea.CollectPathNodes(IList<PathNode> list)
        {
            InvalidateCollisionPolygons();

            if (Collider.IsEmpty)
                return;

            if (pathNodes == null || pathNodes.Length != Collider.Vertices.Count)
                pathNodes = new PathNode[Collider.Vertices.Count];

            for (int i = 0; i < holePolyInflated.Vertices.Count; i++)
            {
                // Is point concave?
                if (holePolyInflated.IsVertexConcave(i))
                    continue;

                // Is point outside walk area
                if (WalkArea != null && !WalkArea.Contains(holePolyInflated.Vertices[i]))
                    continue;

                if (pathNodes[i] == null)
                    pathNodes[i] = new(holePolyInflated.Vertices[i]);
                else
                    pathNodes[i].Position = holePolyInflated.Vertices[i];

                list.Add(pathNodes[i]);
            }
        }

        // Contains
        bool IHoleArea.Contains(Vector2 point)
        {
            InvalidateCollisionPolygons();
            return holePoly.Contains(point);
        }

        // InLineOfSight
        bool IHoleArea.InLineOfSight(Vector2 start, Vector2 end)
        {
            InvalidateCollisionPolygons();
            return holePoly.InLineOfSight(start, end);
        }

        // IsActive
        bool IHoleArea.IsActive => IsWalkAreaHole;

        // Polygon
        ReadOnlyPolygon IHoleArea.Polygon => holePoly;

        #endregion

        #region Private members

        // CheckCollisions
        private void CheckCollisions()
        {
            if (Room == null)
                return;

            for (int i = 0; i < Room.CulledThings.Count; i++)
            {
                // Skip if it is the same thing
                if (Room.CulledThings[i] == this)
                    continue;

                if (Room.CulledThings[i] is GameThing thing)
                {
                    if (thing.IsDead || !thing.CollisionDetection)
                        continue;

                    // If thing is an obstacle (walk area hole)
                    if (thing.RuntimeCollider.Contains(Position))
                    {
                        if (thing is IHoleArea holeArea && holeArea.Contains(Position))
                        {
                            Position = holeArea.ClampOutside(Position);
                            OnCollision(thing);
                        }
                    }
                }
            }
        }

        // GetImpactWordPosition
        private Vector2? GetImpactWordPosition()
        {
            if (HitTestSource == TestPolygon.Collider && !Collider.IsEmpty)
            {
                return this.GetAbsolutePoint(Collider.BoundingRectangleF.GetPoint(RectanglePoint.Top));
            }
            else if (HitTestSource == TestPolygon.Hotspot && RuntimeHotspot != null)
            {
                return RuntimeHotspot.BoundingRectangleF.GetPoint(RectanglePoint.Top);
            }
            else
                return null;
        }

        // GetPivotBasedPolyOffset
        private Vector2 GetPivotBasedPolyOffset()
        {
            var result = new Vector2(X, Y);

            if (Sprite.Pivot.AtMiddleX)
                result.X -= BoundingBox.Width / 2;
            else if (Sprite.Pivot.AtRight)
                result.X -= BoundingBox.Width;

            if (Sprite.Pivot.AtMiddleY)
                result.Y -= BoundingBox.Height / 2;
            else if (Sprite.Pivot.AtBottom)
                result.Y -= BoundingBox.Height;

            return result;
        }

        // InvalidateCollisionPolygons
        private void InvalidateCollisionPolygons()
        {
            if (Collider.IsEmpty || !isCollisionDirty)
                return;

            int vertexCount = Collider.Vertices.Count;
            var vertices = new Vector2[vertexCount];

            var offset = GetPivotBasedPolyOffset();
            Collider.GetVertices(vertices, offset);

            holePoly.SetVertices(vertices);
            holePolyInflated.SetVertices(vertices, .05f);

            if (IsFlippedHorizontally)
            {
                holePoly.FlipHorizontally(X);
                holePolyInflated.FlipHorizontally(X);
            }

            isCollisionDirty = false;
        }

        // InvalidateWalkArea
        private void InvalidateWalkArea()
        {
            if (!string.IsNullOrWhiteSpace(walkAreaName))
                walkArea = Room?.WalkAreas.Find(walkAreaName);
            else
                walkArea = null;

            shouldClampToWalkablePosition = true;
            isCollisionDirty = true;
        }

        #endregion

        #region Protected members

        // CanCheckCollisions
        protected virtual bool CanCheckCollisions() => CollisionDetection;

        // CanInteractCore
        protected virtual bool CanInteractCore(Actor requester)
        {
            if (requester == this || !AllowInteraction)
                return false;

            if (IsDead || string.IsNullOrWhiteSpace(LocalizedDisplayName))
                return false;

            return true;
        }

        // DropLoot
        protected void DropLoot()
        {
            if (Session.Room is ProceduralRoom room && GetLoot() is MetaItem metaItem)
                Session.ObjectPools.Pickables.Get()?.Drop(room, metaItem, Position);
        }

        // GetPixelAreaForGrid
        protected virtual RectangleF GetPixelAreaForGrid()
        {
            if (Collider.IsEmpty)
                return BoundingBox;
            else
                return Collider.BoundingRectangleF;
        }

        // OnCollision
        protected virtual void OnCollision(GameThing thing)
        {
        }

        // OnDie
        protected virtual void OnDie()
        {
        }

        // OnDraw
        protected override void OnDraw(GameTime gameTime)
        {
            if (floatingTween != null && floatingTween.IsRunning)
                Altitude += floatingTween.CurrentValue;

            if (hurtTween != null && hurtTween.IsRunning)
                Altitude += hurtTween.CurrentValue;

            if (hurtShakeTween != null && hurtShakeTween.IsRunning)
                Position += hurtShakeTween.CurrentValue;

            base.OnDraw(gameTime);

            if (floatingTween != null && floatingTween.IsRunning)
                Altitude -= floatingTween.CurrentValue;

            if (hurtTween != null && hurtTween.IsRunning)
                Altitude -= hurtTween.CurrentValue;

            if (hurtShakeTween != null && hurtShakeTween.IsRunning)
                Position -= hurtShakeTween.CurrentValue;
        }

        // OnDrawLights
        protected virtual void OnDrawLights(GameTime gameTime)
        {
        }

        // OnDrawShadow
        protected virtual void OnDrawShadow(GameTime gameTime)
        {
        }

        // OnHealthChanged
        protected virtual void OnHealthChanged()
        {
        }

        // OnHurt
        protected virtual void OnHurt(GameThing attacker, int damage, DamageKind damageKind, Vector2 knockback)
        {
        }

        // OnLoad
        protected override void OnLoad()
        {
            base.OnLoad();
            isCollisionDirty = true;
            InvalidateCollisionPolygons();
            InvalidateWalkArea();
        }

        // OnTransform
        protected override void OnTransform(TransformChange change)
        {
            base.OnTransform(change);

            isHotspotDirty = true;
            shouldClampToWalkablePosition = true;

            if (change != TransformChange.Altitude)
            {
                isCollisionDirty = true;
                InvalidateCollisionPolygons();
            }
        }

        // OnUnload
        protected override void OnUnload()
        {
            base.OnUnload();

            if (impactWord != null)
            {
                Session.ImpactWordPool.Return(impactWord);
                impactWord = null;
            }

            OpacityFactor = 1;
        }

        // OnUpdate
        protected override void OnUpdate(GameTime gameTime)
        {
            floatingTween?.Update(gameTime);
            hurtTween?.Update(gameTime);
            hurtShakeTween?.Update(gameTime);

            if (knockbackTween.IsRunning)
            {
                knockbackTween.Update(gameTime);
                Position = knockbackTween.CurrentValue;
                if (!knockbackTween.IsRunning && IsDead)
                    Die();
            }

            base.OnUpdate(gameTime);

            impactWord?.Update(gameTime);

            if (shouldClampToWalkablePosition || Session.Player == this)
            {
                ClampToWalkablePosition();
                shouldClampToWalkablePosition = false;
            }

            Light?.Update(gameTime);

            if (Blinker.IsRunning)
                Blinker.Update(gameTime);
        }

        // OnUpdateEmittingSound
        protected override void OnUpdateEmittingSound(SoundInstance instance, float masterVolume)
        {
            const int margin = 50;

            RectangleF visible = Session.Camera.VisibleBox;
            //var centerX = visible.Center.X;

            // Expandimos los límites visibles con el margen extra
            float leftLimit = visible.Left - margin;
            float rightLimit = visible.Right + margin;

            // Cálculo del Pan (-1 izquierda, 0 centro, 1 derecha)
            float pan = MathHelper.Clamp(MathHelper.Lerp(-1f, 1f, (X - leftLimit) / (rightLimit - leftLimit)), -1f, 1f);

            // Cálculo del Volumen (1 dentro del VisibleBox, 0 fuera del margen extendido)
            float volume;
            if (visible.Contains(Position))
            {
                volume = 1f;
            }
            else if (X < leftLimit || X > rightLimit)
            {
                volume = 0f;
            }
            else
            {
                float distanceToEdge = Math.Min(Math.Abs(X - visible.Left), Math.Abs(X - visible.Right));
                volume = MathHelper.Clamp(distanceToEdge / margin, 0f, 1f);
            }

            instance.Pan = pan;
            instance.Volume.Current = volume * masterVolume;
        }

        #endregion

        // AllowInteraction
        [ScriptProperty]
        public bool AllowInteraction { get; set; } = true;

        // ApproachPosition
        [ScriptProperty]
        public Vector2 ApproachPosition { get; set; }

        // AttackRange
        [ScriptProperty]
        public int AttackRange { get; set; } = -1;

        // Blinker
        public Blinker<bool> Blinker { get; } = new(false, true);

        // CanInteract
        public bool CanInteract(Actor requester)
        {
            if (!CanInteractCore(requester))
                return false;

            if (InteractionPolygon == TestPolygon.Collider)
                return holePolyInflated.BoundingRectangleF.Intersects(requester.GetAbsoluteBounds(requester.HotspotDetectorArea));
            else
                return RuntimeHotspot.BoundingRectangleF.Intersects(requester.GetAbsoluteBounds(requester.HotspotDetectorArea));
        }

        // CanInteractWithPlayerItems
        [ScriptProperty]
        public bool CanInteractWithPlayerItems
        {
            get
            {
                if (Session.Player == null)
                    return false;

                var friendlyItems = Session.GetFriendlyItems(StaticName);
                var container = Session.Player.Inventory.GetContainer(InventoryCategory.KeyItems);
                for (var i = 0; i < friendlyItems.Length; i++)
                {
                    if (container.Find(friendlyItems[i].Name) != null)
                        return true;
                }

                return false;
            }
        }

        // CellMargin
        [ScriptProperty]
        public int CellMargin { get; set; } = 1;

        // ColliderPlacement
        [ScriptProperty]
        public PlacementMode ColliderPlacement
        {
            get => colliderPlacement;
            set
            {
                if (value != colliderPlacement)
                {
                    colliderPlacement = value;
                    isCollisionDirty = true;
                }
            }
        }

        // ClampToWalkablePosition
        public void ClampToWalkablePosition()
        {
            if (IgnoreWalkArea)
                return;

            // Clamp to a walkable position
            if (WalkArea != null)
            {
                Position = WalkArea.ClampInside(Position, out _);

                for (int i = 0; i < WalkArea.Holes.Count; i++)
                {
                    if (WalkArea.Holes[i].Test())
                        Position = WalkArea.Holes[i].ClampOutside(Position);
                }
            }

            if (CanCheckCollisions())
                CheckCollisions();
        }

        // CollisionDetection
        [ScriptProperty]
        public bool CollisionDetection { get; set; } = true;

        // Collider
        [ScriptProperty]
        public Polygon Collider { get; set; } = new();

        // ContactDamageKind
        public DamageKind ContactDamageKind { get; set; }

        // Die
        [ScriptMethod]
        public void Die()
        {
            Health = 0;

            if (DeathSound != null)
                PlaySound(DeathSound);

            OnDie();
            DropLoot();
        }

#if DEBUG
        // DrawBox
        private static void DrawBox(EngendroGame game, RectangleF bounds, Color color)
        {
            game.Shapes.DrawRectangle(bounds, color);
        }

        // DrawDebugBoxes
        public void DrawDebugBoxes()
        {
            if (ShowColliders)
                DrawBox(Game, holePoly.BoundingRectangleF, Color.Red * .2f);

            if (ShowHotspots)
                DrawBox(Game, RuntimeHotspot.BoundingRectangleF, Color.Purple * .2f);
        }

        // HitEffect
        [ScriptProperty]
        public HitEffect HitEffect { get; set; }

        // ShowColliders
        public static bool ShowColliders { get; set; }

        // ShowHotspots
        public static bool ShowHotspots { get; set; }
#endif

        // DeathSound
        [ScriptProperty]
        public Sound? DeathSound { get; set; }

        // DisplayNameKey
        [ScriptProperty]
        public string DisplayNameKey
        {
            get => displayNameKey;
            set
            {
                if (value != displayNameKey)
                {
                    displayNameKey = value;
                    LocalizedDisplayName = TextRepository.GetValue(DisplayNameKey);
                }
            }
        }

        // DrawImpactWord
        public void DrawImpactWord(GameTime gameTime) => impactWord?.Draw(gameTime);

        // DrawLights
        public void DrawLights(GameTime gameTime)
        {
            if (!IsEmittingLight)
                return;

            if (Light != null)
            {
                Light.Position = this.GetAbsolutePoint(LightPosition);
                Light.Draw(gameTime);
            }

            OnDrawLights(gameTime);
        }

        // DrawShadow
        public void DrawShadow(GameTime gameTime)
        {
            if (!IsDead)
                OnDrawShadow(gameTime);
        }

        // FaceTo
        public void FaceTo(GameThing thing)
        {
            if (X < thing.X)
                Direction = FacingDirection.Right;
            else
                Direction = FacingDirection.Left;
        }

        // FloatingForce
        [ScriptProperty]
        public float FloatingForce
        {
            get => floatingForce;
            set
            {
                if (value != floatingForce)
                {
                    floatingForce = value;

                    if (floatingForce > 0)
                    {
                        floatingTween ??= new FloatTween();
                        floatingTween.Start(TweenStyle.CubicInOut, 0, floatingForce, 200, -1);
                    }
                    else
                        floatingTween?.Stop();
                }
            }
        }

        // GetApproachPosition
        public Vector2 GetApproachPosition(GameThing requester, bool inFront)
        {
            if (ApproachPosition != Vector2.Zero)
                return this.GetAbsolutePoint(ApproachPosition);

            var box = RuntimeHotspot.BoundingRectangleF;
            if (box.IsEmpty)
                box = BoundingBox;

            var requesterBox = requester.RuntimeHotspot.BoundingRectangleF;
            if (requesterBox.IsEmpty)
                requesterBox = requester.BoundingBox;

            Vector2 result;

            if (inFront)
            {
                var offset = this is Actor ? requesterBox.Width + 3 : requesterBox.Width / 2;
                if (Direction == FacingDirection.Left)
                    result = box.GetPoint(RectanglePoint.LeftBottom, -offset, 0);
                else
                    result = box.GetPoint(RectanglePoint.RightBottom, offset, 0);
            }
            else
            {
                // Doesn't matter the enemy facing direction
                if (requester.X <= X)
                    result = box.GetPoint(RectanglePoint.LeftBottom, -requesterBox.Width / 2, 0);
                else
                    result = box.GetPoint(RectanglePoint.RightBottom, requesterBox.Width / 2, 0);
            }

            result.Y = BoundingBox.Bottom + Altitude;

            return result;
        }

        // GetFloatingTextPosition
        public Vector2 GetFloatingTextPosition(Vector2 knockback) => GetFloatingTextPosition(knockback, 0, 0);

        // GetFloatingTextPosition
        public Vector2 GetFloatingTextPosition(Vector2 knockback, int xOffset, int yOffset)
        {
            var result = GetOverheadPosition();

            if (Direction == FacingDirection.Right)
                result.X -= Math.Abs(knockback.X);
            else
                result.X += Math.Abs(knockback.X);

            result.X += xOffset;
            result.Y += yOffset;

            return result;
        }

        // GetFrameSubArea
        public RectangleF GetFrameSubArea()
        {
            if (AnimationPlayer.Frame != null)
                return this.GetAbsoluteBounds(AnimationPlayer.Frame.SubArea);
            else
                return RectangleF.Empty;
        }

        // GetLoot
        public MetaItem? GetLoot()
        {
            if (LootTable.Find(LootTableName) is LootTable lootTable && lootTable.GetLoot() is MetaItem metaItem)
                return metaItem;

            return null;
        }

        // GetOverheadPosition
        public Vector2 GetOverheadPosition() => GetOverheadPosition(0, 0);

        // GetOverheadPosition
        public Vector2 GetOverheadPosition(int xOffset, int yOffset)
        {
            // Origin
            if (OverheadOrigin == Vector2.Zero)
                return BoundingBox.GetPoint(RectanglePoint.Top, xOffset, yOffset);
            else
                return this.GetAbsolutePoint(OverheadOrigin, xOffset, yOffset);
        }

        // GetRequiredGridSpace
        public Size GetRequiredGridSpace(int cellSize)
        {
            var bbox = GetPixelAreaForGrid();
            int width = (int)Math.Ceiling(bbox.Width / cellSize) + CellMargin * 2;
            int height = (int)Math.Ceiling(bbox.Height / cellSize) + CellMargin * 2;

            return new Size(width, height);
        }

        // GetFootstepSound
        public Sound? GetFootstepSound(Vector2 position)
        {
            if (RuntimeHotspot?.Contains(position) == true)
                return TerrainSound;

            return null;
        }

        // GetThrowableSpawnPosition
        public Vector2 GetThrowableSpawnPosition() => this.GetAbsolutePoint(ThrowableSpawnPosition);

        // Health
        [ScriptProperty]
        public int Health
        {
            get => health;
            set
            {
                if (value != health)
                {
                    health = Math.Min(value, MaxHealth);
                    OnHealthChanged();
                }
            }
        }

        // HitTest
        public bool HitTest(Vector2 value)
        {
            if (HitTestSource == TestPolygon.Hotspot)
                return RuntimeHotspot.Contains(value);
            else
                return (this as IHoleArea).Contains(value);
        }

        // HitTestSource
        [ScriptProperty]
        public TestPolygon HitTestSource { get; set; }

        // Hotspot
        [ScriptProperty]
        public Polygon Hotspot { get; set; } = new();

        // HotspotPlacement
        [ScriptProperty]
        public PlacementMode HotspotPlacement
        {
            get => hotspotPlacement;
            set
            {
                if (value != hotspotPlacement)
                {
                    hotspotPlacement = value;
                    isHotspotDirty = true;
                }
            }
        }

        // HurtShake
        [ScriptProperty]
        public Vector2 HurtShake { get; set; } = new Vector2(.5f, 0);

        // HurtImpactSound
        [ScriptProperty]
        public Sound? HurtImpactSound { get; set; }

        // HurtSound
        [ScriptProperty]
        public Sound? HurtSound { get; set; }

        // IgnoreThrowables
        [ScriptProperty]
        public bool IgnoreThrowables { get; set; }

        // IgnoreWalkArea
        [ScriptProperty]
        public bool IgnoreWalkArea { get; set; } = true;

        // InteractionPolygon
        [ScriptProperty]
        public TestPolygon InteractionPolygon { get; set; } = TestPolygon.Collider;

        // InvulnerabilityPeriod
        [ScriptProperty]
        public bool InvulnerabilityPeriod { get; set; }

        // IsBehind
        public bool IsBehind(GameThing thing)
        {
            if (thing.Direction == FacingDirection.Right && X < thing.X)
                return true;

            else if (thing.Direction == FacingDirection.Left && X > thing.X)
                return true;

            else
                return false;
        }

        // IsDead
        public bool IsDead => Health <= 0 && MaxHealth > 0;

        // IsEmittingLight
        public virtual bool IsEmittingLight => Light != null && Light.IsEmitting;

        // IsMouseOver
        public bool IsMouseOver()
        {
            if (InputManager.DefaultPlayer.LastInputMethod != InputMethod.Mouse)
                return false;

            if (RuntimeHotspot.IsEmpty)
                return BoundingBox.Contains(InputManager.DefaultPlayer.Mouse.WorldPosition(Session.Camera));
            else
                return RuntimeHotspot.Contains(InputManager.DefaultPlayer.Mouse.WorldPosition(Session.Camera));
        }

        // IsWalkAreaHole
        [ScriptProperty]
        public virtual bool IsWalkAreaHole => !Collider.IsEmpty;

        // Light
        public Light? Light { get; set; }

        // LightPosition
        public Vector2 LightPosition { get; set; }

        // LocalizedDisplayName
        public string LocalizedDisplayName { get; private set; } = string.Empty;

        // LootTableName
        [ScriptProperty]
        public string LootTableName { get; set; }

        // MaxHealth
        [ScriptProperty]
        public int MaxHealth
        {
            get => maxHealth;
            set
            {
                if (value != maxHealth)
                {
                    maxHealth = value;
                    Health = value;
                }
            }
        }

        // OverheadOrigin
        [ScriptProperty]
        public Vector2 OverheadOrigin { get; set; }

        // PlacementPhase
        [ScriptProperty]
        public PlacementPhase PlacementPhase { get; set; }

        // PowerBonus
        [ScriptProperty]
        public int PowerBonus { get; set; }

        // PreventKnockback
        [ScriptProperty]
        public bool PreventKnockback { get; set; }

        // Reheal
        [ScriptMethod]
        public virtual void Reheal() => Health = MaxHealth;

        // RenderLayer
        [ScriptProperty]
        public RenderLayer RenderLayer
        {
            get => renderLayer;
            set
            {
                if (value != renderLayer)
                {
                    renderLayer = value;
                    renderLayerDepth = (int)renderLayer;
                }
            }
        }

        // RenderLayerDepth
        public override int RenderLayerDepth => renderLayerDepth;

        // Room
        public new GameRoom? Room => Parent as GameRoom;

        // RuntimeCollider
        public Polygon RuntimeCollider => holePolyInflated;

        // RuntimeHotspot
        public Polygon RuntimeHotspot
        {
            get
            {
                if (isHotspotDirty)
                {
                    if (Hotspot.IsEmpty)
                    {
                        hotspotPoly.Clear();
                    }
                    else if (HotspotPlacement == PlacementMode.Relative)
                    {
                        var offset = GetPivotBasedPolyOffset();
                        offset.Y -= Altitude;

                        var vertices = new Vector2[Hotspot.Vertices.Count];
                        Hotspot.GetVertices(vertices, offset);
                        hotspotPoly.SetVertices(vertices);
                        if (IsFlippedHorizontally)
                            hotspotPoly.FlipHorizontally(X);
                    }
                    else
                    {
                        isHotspotDirty = false;
                        return Hotspot;
                    }

                    isHotspotDirty = false;
                }

                return hotspotPoly;
            }
        }

        // ScoreValue
        [ScriptProperty]
        public int ScoreValue { get; set; }

        // Session
        public new GameSession Session { get; }

        // ShakeOnHit
        public bool ShakeOnHit { get; set; }

        // TakeDamage
        public void TakeDamage(GameThing attacker, int amount, DamageKind damageKind, DamageIntensity damageIntensity, Vector2 knockback, ImpactWordName impactWord)
        {
            if (IsDead || amount <= 0)
                return;

            if (InvulnerabilityPeriod && Blinker.IsRunning)
                return;

            knockback = PreventKnockback ? Vector2.Zero : knockback;

            if (HurtSound != null)
                PlaySound(HurtSound);

            if (HurtImpactSound != null)
                PlaySound(HurtImpactSound);

            if (HitEffect == HitEffect.Shake)
            {
                hurtShakeTween ??= new();
                hurtShakeTween.Start(TweenStyle.Linear, Vector2.Zero, HurtShake, 40, 4);
            }

            // Impact word
            if (impactWord != ImpactWordName.None && GetImpactWordPosition() is Vector2 wordPos)
            {
                this.impactWord ??= Session.ImpactWordPool.Get();
                this.impactWord.Show(impactWord, wordPos);
            }

            if (MaxHealth == 0)
                return;

            if (amount > Health)
                amount = Health;

            Health -= amount;

            if (knockback == Vector2.Zero && Health <= 0)
            {
                Die();
            }
            else
            {
                var destination = Position;

                if (X > attacker.X)
                    destination.X += knockback.X;
                else
                    destination.X -= knockback.X;

                var bottomDistance = Math.Abs(Y - attacker.Y);
                var topDistance = Math.Abs(Y - attacker.BoundingBox.Top);

                if (knockback != Vector2.Zero)
                {
                    if (bottomDistance < topDistance)
                        destination.Y += knockback.Y;
                    else
                        destination.Y -= knockback.Y;

                    knockbackTween.Start(TweenStyle.CubicOut, Position, destination, 400, 0);
                }

                hurtTween ??= new();
                hurtTween.Start(TweenStyle.Linear, 0, 1, 150, 2);

                Blinker.Start(20, 5);

                Session.ObjectPools.FloatingTexts.Get()?.Show(GetFloatingTextPosition(knockback), amount.ToString(), damageIntensity);

                if (Session.Player == attacker)
                    Session.HUD.TargetMeter.Target = this;
                
                else if (Session.Player == this)
                    Session.HUD.TargetMeter.Target = attacker;

                OnHurt(attacker, amount, damageKind, knockback);
            }
        }

        // TerrainParticleColor
        [ScriptProperty]
        public Color TerrainParticleColor { get; set; }

        // TerrainSound
        [ScriptProperty]
        public Sound? TerrainSound { get; set; }

        // ThrowableSpawnPosition
        [ScriptProperty]
        public Vector2 ThrowableSpawnPosition { get; set; }

        // ViewAngle
        public float ViewAngle { get; set; } = 90;

        // ViewDistance
        [ScriptProperty]
        public float ViewDistance { get; set; }

        // WalkArea
        public WalkArea? WalkArea => walkArea ?? Room?.WalkArea;

        // WalkAreaName
        [ScriptProperty]
        public string WalkAreaName
        {
            get => walkAreaName;
            set
            {
                if (value != walkAreaName)
                {
                    walkAreaName = value;
                    InvalidateWalkArea();
                }
            }
        }
    }
}