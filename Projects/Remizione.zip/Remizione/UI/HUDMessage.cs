﻿using Engendro;
using Engendro.Audio;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Remizione
{
    /// <summary>
    /// HUDMessage
    /// </summary>
    public sealed class HUDMessage : GameObject
    {
        private readonly FloatTween fadeTween = new() { StartDelay = 1500 };
        private readonly TextSprite messageText;
        private readonly Vector2Tween scaleTween = new();

        // Constructor
        public HUDMessage(EngendroGame game)
            : base(game)
        {
            // Message text
            this.messageText = new(Game, Fonts.CommonOutline)
            {
                Color = ColorPalette.Text.Highlight,
                MaximumWidth = (int)(Screen.HUDArea.Width * .7f),
                PivotOrigin = RectanglePoint.Center,
                Position = Screen.HUDArea.GetPoint(RectanglePoint.Top, 0, 15)
            };
        }

        #region Protected members

        // OnDraw
        protected override void OnDraw(GameTime gameTime)
        {
            if (!fadeTween.IsRunning)
                return;

            Game.SpriteBatch.Begin(Game.Camera, SamplerState.PointClamp);
            messageText.Draw(gameTime);
            Game.SpriteBatch.End();
        }

        // OnUpdate
        protected override void OnUpdate(GameTime gameTime)
        {
            fadeTween.Update(gameTime);
            messageText.Update(gameTime);
            messageText.Opacity = fadeTween.IsRunning ? fadeTween.CurrentValue : 1;
        }

        #endregion

        // Hide
        public void Hide() => fadeTween.Stop();

        // Show
        public void Show(HUDMessageKind message)
        {
            messageText.Text = Localization.GetValue(message);
            fadeTween.Start(TweenStyle.CubicIn, 1, 0, 200);

            if (message == HUDMessageKind.MagneticCardRequired)
            {
                messageText.Color = ColorPalette.Text.Orange;
                Sound.Play(SoundNames.Error);
            }
            else if (message == HUDMessageKind.ExtraTime)
            {
                messageText.Color = ColorPalette.Text.Orange;
            }
            else
            {
                messageText.Color = ColorPalette.Text.Highlight;
                Sound.Play(SoundNames.Error);
            }

            scaleTween.Start(TweenStyle.CubicIn, ScaleInfo.Text.ExtraLarge * .8f, ScaleInfo.Text.ExtraLarge, 50);
            messageText.Tweens.ScaleTween = scaleTween;
        }
    }
}
